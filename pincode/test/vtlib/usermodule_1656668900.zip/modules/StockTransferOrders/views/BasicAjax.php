<?php


class StockTransferOrders_BasicAjax_View extends Vtiger_BasicAjax_View {
    
    
}