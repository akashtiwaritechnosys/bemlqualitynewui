<?php

class StockTransferOrders_SubProductsPopup_View extends Inventory_SubProductsPopup_View {}