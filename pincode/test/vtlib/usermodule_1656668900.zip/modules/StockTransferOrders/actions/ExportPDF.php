<?php

vimport('~~/modules/StockTransferOrders/StockTransferOrdersPDFController.php');
class StockTransferOrders_ExportPDF_Action extends Inventory_ExportPDF_Action {}
