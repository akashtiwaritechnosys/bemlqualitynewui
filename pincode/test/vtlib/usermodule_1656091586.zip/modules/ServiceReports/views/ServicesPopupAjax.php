<?php


class ServiceReports_ServicesPopupAjax_View extends Inventory_ServicesPopupAjax_View {}