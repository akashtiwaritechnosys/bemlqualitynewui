<?php


class ServiceReports_RecordQuickPreview_View extends Inventory_RecordQuickPreview_View {}
