<?php


class ServiceReports_ProductsPopup_View extends Inventory_ProductsPopup_View {}