<?php


class ServiceReports_ServicesPopup_View extends Inventory_ServicesPopup_View {}