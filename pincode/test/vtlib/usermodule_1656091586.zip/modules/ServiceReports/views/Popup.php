<?php


class ServiceReports_Popup_View extends Inventory_Popup_View {
    
}