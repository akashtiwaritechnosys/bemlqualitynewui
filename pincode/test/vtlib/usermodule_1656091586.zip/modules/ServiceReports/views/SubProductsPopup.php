<?php

class ServiceReports_SubProductsPopup_View extends Inventory_SubProductsPopup_View {}