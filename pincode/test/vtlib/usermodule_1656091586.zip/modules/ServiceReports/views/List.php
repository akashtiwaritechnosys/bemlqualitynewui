<?php


class ServiceReports_List_View extends Inventory_List_View {}
?>
