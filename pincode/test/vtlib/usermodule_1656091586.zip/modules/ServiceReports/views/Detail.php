<?php


class ServiceReports_Detail_View extends Inventory_Detail_View {
    
}