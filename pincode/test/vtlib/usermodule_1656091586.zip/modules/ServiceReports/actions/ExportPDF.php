<?php

vimport('~~/modules/ServiceReports/ServiceReportsPDFController.php');
class ServiceReports_ExportPDF_Action extends Inventory_ExportPDF_Action {}
