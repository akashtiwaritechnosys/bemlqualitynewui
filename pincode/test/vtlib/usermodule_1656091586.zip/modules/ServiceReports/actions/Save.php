<?php
class ServiceReports_Save_Action extends Inventory_Save_Action {}
