<?php

class ServiceReports_BasicAjax_Action extends Inventory_BasicAjax_Action {}
