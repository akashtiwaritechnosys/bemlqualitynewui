<?php

class ServiceReports_DetailView_Model extends Inventory_DetailView_Model {

}
