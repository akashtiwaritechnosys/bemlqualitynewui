
Inventory_List_Js("ServiceReports_List_Js",{},{});