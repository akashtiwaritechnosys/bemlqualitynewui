
Inventory_Detail_Js("ServiceReports_Detail_Js", {}, {

    postMailSentEvent: function () {
        window.location.reload();
    },
});