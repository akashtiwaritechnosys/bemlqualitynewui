
Inventory_Detail_Js("StockTransferOrders_Detail_Js", {}, {

    postMailSentEvent: function () {
        window.location.reload();
    },
});