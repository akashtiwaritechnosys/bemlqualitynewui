<?php
class StockTransferOrders_Save_Action extends Inventory_Save_Action {}
