<?php

class StockTransferOrders_BasicAjax_Action extends Inventory_BasicAjax_Action {}
