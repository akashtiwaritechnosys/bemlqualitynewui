<?php


class StockTransferOrders_RecordQuickPreview_View extends Inventory_RecordQuickPreview_View {}
