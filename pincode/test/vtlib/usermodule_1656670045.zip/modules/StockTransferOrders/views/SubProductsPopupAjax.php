<?php


class StockTransferOrders_SubProductsPopupAjax_View extends Inventory_SubProductsPopupAjax_View {}