<?php


class StockTransferOrders_ServicesPopup_View extends Inventory_ServicesPopup_View {}