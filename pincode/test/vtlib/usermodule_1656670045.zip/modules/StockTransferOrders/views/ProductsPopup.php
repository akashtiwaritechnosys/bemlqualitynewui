<?php


class StockTransferOrders_ProductsPopup_View extends Inventory_ProductsPopup_View {}