<?php


class StockTransferOrders_Detail_View extends Inventory_Detail_View {
    
}