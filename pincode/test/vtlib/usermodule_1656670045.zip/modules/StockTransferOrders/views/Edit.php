<?php


Class StockTransferOrders_Edit_View extends Inventory_Edit_View {
    
}