<?php

class StockTransferOrders_DetailView_Model extends Inventory_DetailView_Model {

}
