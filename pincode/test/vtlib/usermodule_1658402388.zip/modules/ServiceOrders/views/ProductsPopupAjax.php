<?php

class ServiceOrders_ProductsPopupAjax_View extends Inventory_ProductsPopupAjax_View {}