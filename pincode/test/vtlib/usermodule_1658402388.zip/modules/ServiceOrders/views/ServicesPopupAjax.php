<?php


class ServiceOrders_ServicesPopupAjax_View extends Inventory_ServicesPopupAjax_View {}