<?php


class ServiceOrders_List_View extends Inventory_List_View {}
?>
