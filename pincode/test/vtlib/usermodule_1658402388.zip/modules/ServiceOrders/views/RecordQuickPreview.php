<?php


class ServiceOrders_RecordQuickPreview_View extends Inventory_RecordQuickPreview_View {}
