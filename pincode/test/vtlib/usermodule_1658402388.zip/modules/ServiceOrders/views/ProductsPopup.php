<?php


class ServiceOrders_ProductsPopup_View extends Inventory_ProductsPopup_View {}