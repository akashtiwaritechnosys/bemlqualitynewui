<?php

class ServiceOrdersHandler extends VTEventHandler {

    function handleEvent($eventName, $entityData) {
        
    }

}