<?php

require_once("include/events/include.inc");
require_once 'include/Webservices/LineItem/VtigerInventoryOperation.php';

class ServiceOrdersModuleOperation extends VtigerInventoryOperation {

}
