<?php

class ServiceOrders_RelationListView_Model extends Inventory_RelationListView_Model {}
?>