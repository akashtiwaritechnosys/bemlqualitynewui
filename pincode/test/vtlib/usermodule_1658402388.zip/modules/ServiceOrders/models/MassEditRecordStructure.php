<?php

class ServiceOrders_MassEditRecordStructure_Model extends Inventory_MassEditRecordStructure_Model {}
