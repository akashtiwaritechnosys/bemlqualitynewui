<?php

class ServiceOrders_EditRecordStructure_Model extends Inventory_EditRecordStructure_Model {}