<?php

vimport('~~/modules/ServiceOrders/ServiceOrdersPDFController.php');
class ServiceOrders_ExportPDF_Action extends Inventory_ExportPDF_Action {}
