<?php
class ServiceOrders_Save_Action extends Inventory_Save_Action {}
