<?php

class ServiceOrders_MassSave_Action extends Inventory_MassSave_Action {}