<?php

class ServiceOrders_BasicAjax_Action extends Inventory_BasicAjax_Action {}
