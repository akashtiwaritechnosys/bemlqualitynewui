<?php

$languageStrings = array(
    'LBL_ADD_RECORD' => 'Add ServiceOrders',
    'Name' => 'Name',
    'Status' => 'Status',
    'Account Name' => 'Organization Name',
    'Contact Name' => 'Contact Name',
    'Reason' => 'Reason',
    'paymentsno' => 'Receipt no',
    'invoice_no' => 'Invoice no',
    'StockTransferOrder No' => 'ServiceOrders No',
    'Invoice No' => 'Invoice No',
    'Invoice Date' => 'Invoice Date',
    'Refund' => 'Refund',
    'LBL_Preinvoice_INFORMATION' => 'ServiceOrders Details',
    'LBL_SYSTEM_INFORMATION' => 'System Details',
    'LBL_SEND_MAIL_PDF' => 'Send Email with PDF',
    'LBL_AVAILABLE_INVOICE' => 'Available open Invoices',
    'LBL_INVOICE_BALANCE' => 'Invoice balance',
    'LBL_INVOICE_BALANCE_DUE' => 'Invoice balance due',
    'LBL_NOT_ALLOWED' => 'Not allowed',
);
$jsLanguageStrings = array(
);
